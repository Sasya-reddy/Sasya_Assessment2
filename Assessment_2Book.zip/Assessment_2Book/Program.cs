﻿using System;
using System.Collections.Generic;

namespace LibraryManagement
{
    public class Book
    {
        public int BookId { get; set; }
        public string BookName { get; set; }
        public double Price { get; set; }
        public string Author { get; set; }
        public string Publisher { get; set; }

        public override string ToString()
        {
            return $"ID: {BookId}, Name: {BookName}, Price: {Price}, Author: {Author}, Publisher: {Publisher}";
        }

        interface IBookRepository
        {
            void CreateBook(Book book);
            void UpdateBook(Book book);
            Book GetBookById(int bookId);
            Book GetBookByName(string bookName);
            List<Book> GetBooksByAuthor(string author);
            List<Book> GetBooksByAuthorAndPublisher(string author, string publisher);
            List<Book> GetAllBooks();
        }

        class BookRepository : IBookRepository
        {
            private List<Book> books = new List<Book>();

            public void CreateBook(Book book)
            {
                try
                {
                    books.Add(book);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            public void UpdateBook(Book book)
            {
                try
                {
                    var old = GetBookById(book.BookId);

                    old.BookName = book.BookName;
                    old.Price = book.Price;
                    old.Author = book.Author;
                    old.Publisher = book.Publisher;

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            public Book GetBookById(int bookId)
            {
                try
                {
                    return books.Find(book => book.BookId == bookId);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }

            public Book GetBookByName(string bookName)
            {
                try
                {
                    return books.Find(book => book.BookName == bookName);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }

            public List<Book> GetBooksByAuthor(string author)
            {
                try
                {
                    return books.FindAll(book => book.Author == author);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return new List<Book>();
                }
            }

            public List<Book> GetBooksByAuthorAndPublisher(string author, string publisher)
            {
                try
                {
                    return books.FindAll(book => book.Author == author && book.Publisher == publisher);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);

                    return new List<Book>();
                }
            }

            public List<Book> GetAllBooks()
            {
                try
                {
                    return books;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);

                    return new List<Book>();
                }
            }
        }

        internal class Demo
        {
            static void Main()
            {
                IBookRepository repository = new BookRepository();
                do
                {
                    Console.WriteLine("CHOOSE OPTION: ");

                    Console.WriteLine("1. Create Book");
                    Console.WriteLine("2. Update Book Details");
                    Console.WriteLine("3.Display Book Details");

                    Console.WriteLine("4. Exit");
                    int option = int.Parse(Console.ReadLine());
                    switch (option)
                    {
                        case 1:
                            {
                                Book book = new Book();
                                Console.WriteLine("enter BOOKID");
                                book.BookId = int.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Book Name:");
                                book.BookName = Console.ReadLine();
                                Console.WriteLine("Enter Price:");
                                book.Price = double.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Author:");
                                book.Author = Console.ReadLine();
                                Console.WriteLine("Enter Publisher:");
                                book.Publisher = Console.ReadLine();
                                repository.CreateBook(book);
                            }
                            break;
                        case 2:
                            {
                                Book book = new Book();
                                Console.WriteLine("Enter Book ID:");
                                book.BookId = int.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Book Name");
                                string bookName = Console.ReadLine();
                                book.BookName = bookName;
                                Console.WriteLine("Enter Price ");
                                string priceInput = Console.ReadLine();
                                book.Price = double.Parse(priceInput);
                                Console.WriteLine("Enter Author ");
                                string author = Console.ReadLine();
                                book.Author = author;
                                Console.WriteLine("Enter Publisher");
                                string publisher = Console.ReadLine();
                                book.Publisher = publisher;
                                repository.UpdateBook(book);
                            }
                            break;


                        case 3:
                            {
                                Console.WriteLine("1. Display book details based on Book ID");
                                Console.WriteLine("2. Display book details based on Book Name");
                                Console.WriteLine("3. Display all books based on Author");
                                Console.WriteLine("4. Display all books based on Author and Publisher");
                                Console.WriteLine("5. Display all books details");
                                Console.WriteLine("Select Option:");
                                int displayOption = int.Parse(Console.ReadLine());
                                switch (displayOption)
                                {
                                    case 1:
                                        Console.WriteLine("Enter Book ID:");
                                        int bookId = int.Parse(Console.ReadLine());
                                        Book bookById = repository.GetBookById(bookId);
                                        Console.WriteLine(bookById);

                                        break;

                                    case 2:
                                        Console.WriteLine("Enter Book Name:");
                                        string bookName = Console.ReadLine();
                                        Book bookByName = repository.GetBookByName(bookName);
                                        Console.WriteLine(bookByName);

                                        break;
                                    case 3:
                                        Console.WriteLine("Enter Author:");
                                        string author = Console.ReadLine();
                                        List<Book> booksByAuthor = repository.GetBooksByAuthor(author);
                                        if (booksByAuthor.Count > 0)
                                        {
                                            foreach (var book in booksByAuthor)
                                            {
                                                Console.WriteLine(book);
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("No books found.");
                                        }
                                        break;
                                    case 4:
                                        Console.WriteLine("Enter Author:");
                                        string author1 = Console.ReadLine();
                                        Console.WriteLine("Enter Publisher:");
                                        string publisher = Console.ReadLine();
                                        List<Book> booksByAuthorAndPublisher = repository.GetBooksByAuthorAndPublisher(author1, publisher);
                                        if (booksByAuthorAndPublisher.Count > 0)
                                        {
                                            foreach (var book in booksByAuthorAndPublisher)
                                            {
                                                Console.WriteLine(book);
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("No books found.");
                                        }
                                        break;
                                    case 5:
                                        List<Book> allBooks = repository.GetAllBooks();
                                        if (allBooks.Count > 0)
                                        {
                                            foreach (var book in allBooks)
                                            {
                                                Console.WriteLine(book);
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("Not Found.");
                                        }
                                        break;
                                    default:
                                        Console.WriteLine("Choose Correct Option");
                                        break;
                                }
                            }
                            break;
                        case 4:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Choose Correct  Option");
                            break;
                    }
                } while (true);
            }
        }
    }
}